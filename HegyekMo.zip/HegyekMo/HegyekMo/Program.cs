﻿StreamReader sr = new StreamReader("hegyekMo.txt");

int hanyhegyvan = 0;

List<int> magassagok = new List<int>();


while (!sr.EndOfStream)
{
    if (sr.ReadLine() != "Hegycsúcs neve;Hegység;Magasság")
    {
        string[] hegyek = sr.ReadLine().Split(";");
        hanyhegyvan++;
        magassagok.Add(int.Parse(hegyek[2]));
    }
}


Console.WriteLine($"3.feladat: Hegycsúcsok száma: {hanyhegyvan} db");
Console.WriteLine($"4.feladat: Hegycsúcsok átlagos magassága: {Math.Round(magassagok.Average(x => x), 2)}m");
Console.WriteLine($"5.feladat: Legmagasabb hegy adatai: {magassagok.Max(x => x)}");
double bekertmagassag = Convert.ToDouble(Console.ReadLine());
Console.WriteLine($"6.feladat: Kérem a magasságot: {bekertmagassag}, A megadott magasságnál magasabb hegyek száma: {magassagok.Count(x => x > bekertmagassag)}");
string hegysegneve = Console.ReadLine();
Console.WriteLine($"7.feladat: Kérem a hegység nevét: {hegysegneve}, ");
Console.WriteLine($"8.feladat: {magassagok.OrderByDescending(x => x).ToList()}");




sr.Close();
